create definer = root@`%` view amount_view as
select `i`.`patId`     AS `patId`,
       `i`.`amount`    AS `amount`,
       `i`.`ioDefId`   AS `ioDefId`,
       `i`.`startTime` AS `startTime`,
       `i`.`endTime`   AS `endTime`
from `sd20210809`.`pat_inamount_record` `i`
union all
select `m`.`patId`     AS `patId`,
       `m`.`dosage`    AS `dosage`,
       `m`.`medId`     AS `medId`,
       `m`.`startTime` AS `startTime`,
       `m`.`endTime`   AS `endTime`
from `sd20210809`.`pat_medical_record` `m`;

