create definer = root@`%` view view_bas_region_bed as
select `sd20210809`.`bas_region_bed`.`id`        AS `id`,
       `sd20210809`.`bas_region_bed`.`name`      AS `name`,
       `sd20210809`.`bas_region_bed`.`type`      AS `type`,
       `sd20210809`.`bas_region_bed`.`level`     AS `level`,
       `sd20210809`.`bas_region_bed`.`operClass` AS `operClass`,
       `sd20210809`.`bas_region_bed`.`deptId`    AS `deptId`,
       `sd20210809`.`bas_region_bed`.`deptName`  AS `deptName`,
       `sd20210809`.`bas_region_bed`.`patId`     AS `patId`,
       `sd20210809`.`bas_region_bed`.`ipAddr`    AS `ipAddr`,
       `sd20210809`.`bas_region_bed`.`port`      AS `port`,
       `sd20210809`.`bas_region_bed`.`status`    AS `status`,
       `sd20210809`.`bas_region_bed`.`sampFreq1` AS `sampFreq1`,
       `sd20210809`.`bas_region_bed`.`sampFreq2` AS `sampFreq2`,
       `sd20210809`.`bas_region_bed`.`hisBedId`  AS `hisBedId`,
       `sd20210809`.`bas_region_bed`.`hisBedNO`  AS `hisBedNO`,
       `sd20210809`.`bas_region_bed`.`beid`      AS `beid`
from `sd20210809`.`bas_region_bed`;

