create definer = root@`%` view view_sco_title as
select `sd20210809`.`sco_title`.`scoTitleId`      AS `scoTitleId`,
       `sd20210809`.`sco_title`.`scoThemeId`      AS `scoThemeId`,
       `sd20210809`.`sco_title`.`title`           AS `title`,
       `sd20210809`.`sco_title`.`desc`            AS `desc`,
       `sd20210809`.`sco_title`.`type`            AS `type`,
       `sd20210809`.`sco_title`.`hasInput`        AS `hasInput`,
       `sd20210809`.`sco_title`.`maxSco`          AS `maxSco`,
       `sd20210809`.`sco_title`.`minSco`          AS `minSco`,
       `sd20210809`.`sco_title`.`minHeight`       AS `minHeight`,
       `sd20210809`.`sco_title`.`minWidthPercent` AS `minWidthPercent`,
       `sd20210809`.`sco_title`.`showScore`       AS `showScore`,
       `sd20210809`.`sco_title`.`groupName`       AS `groupName`,
       `sd20210809`.`sco_title`.`showGroupScore`  AS `showGroupScore`,
       `sd20210809`.`sco_title`.`other`           AS `other`,
       `sd20210809`.`sco_title`.`enable`          AS `enable`,
       `sd20210809`.`sco_title`.`sort`            AS `sort`,
       `sd20210809`.`sco_title`.`childoption`     AS `childoption`
from `sd20210809`.`sco_title`;

