create definer = root@`%` view view_bas_io_def as
select `sd20210809`.`bas_io_def`.`id`              AS `id`,
       `sd20210809`.`bas_io_def`.`code`            AS `code`,
       `sd20210809`.`bas_io_def`.`type`            AS `type`,
       `sd20210809`.`bas_io_def`.`subType`         AS `subType`,
       `sd20210809`.`bas_io_def`.`name`            AS `name`,
       `sd20210809`.`bas_io_def`.`briefName`       AS `briefName`,
       `sd20210809`.`bas_io_def`.`unit`            AS `unit`,
       `sd20210809`.`bas_io_def`.`spec`            AS `spec`,
       `sd20210809`.`bas_io_def`.`pinyin`          AS `pinyin`,
       `sd20210809`.`bas_io_def`.`dosageUnit`      AS `dosageUnit`,
       `sd20210809`.`bas_io_def`.`pkgDosageAmount` AS `pkgDosageAmount`,
       `sd20210809`.`bas_io_def`.`enable`          AS `enable`,
       `sd20210809`.`bas_io_def`.`beid`            AS `beid`,
       `sd20210809`.`bas_io_def`.`warning`         AS `warning`,
       `sd20210809`.`bas_io_def`.`warningContent`  AS `warningContent`
from `sd20210809`.`bas_io_def`;

