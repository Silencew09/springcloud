create definer = root@`%` view view_pat_docord_execute_detail as
select `sd20210809`.`pat_docord_execute_detail`.`id`               AS `id`,
       `sd20210809`.`pat_docord_execute_detail`.`pat_id`           AS `pat_id`,
       `sd20210809`.`pat_docord_execute_detail`.`docord_id`        AS `docord_id`,
       `sd20210809`.`pat_docord_execute_detail`.`docord_group_id`  AS `docord_group_id`,
       `sd20210809`.`pat_docord_execute_detail`.`docord_excute_id` AS `docord_excute_id`,
       `sd20210809`.`pat_docord_execute_detail`.`docord_sub_type`  AS `docord_sub_type`,
       `sd20210809`.`pat_docord_execute_detail`.`medicine_id`      AS `medicine_id`,
       `sd20210809`.`pat_docord_execute_detail`.`way`              AS `way`,
       `sd20210809`.`pat_docord_execute_detail`.`matter`           AS `matter`,
       `sd20210809`.`pat_docord_execute_detail`.`dosage`           AS `dosage`,
       `sd20210809`.`pat_docord_execute_detail`.`unit`             AS `unit`,
       `sd20210809`.`pat_docord_execute_detail`.`start_time`       AS `start_time`,
       `sd20210809`.`pat_docord_execute_detail`.`end_time`         AS `end_time`,
       `sd20210809`.`pat_docord_execute_detail`.`excute_id`        AS `excute_id`,
       `sd20210809`.`pat_docord_execute_detail`.`beid`             AS `beid`,
       `sd20210809`.`pat_docord_execute_detail`.`create_time`      AS `create_time`,
       `sd20210809`.`pat_docord_execute_detail`.`create_id`        AS `create_id`,
       `sd20210809`.`pat_docord_execute_detail`.`update_time`      AS `update_time`,
       `sd20210809`.`pat_docord_execute_detail`.`update_id`        AS `update_id`,
       `sd20210809`.`pat_docord_execute_detail`.`remark`           AS `remark`
from `sd20210809`.`pat_docord_execute_detail`;

