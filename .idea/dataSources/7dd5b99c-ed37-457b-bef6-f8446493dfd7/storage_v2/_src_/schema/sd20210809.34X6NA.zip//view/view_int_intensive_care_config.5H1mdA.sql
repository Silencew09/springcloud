create definer = root@`%` view view_int_intensive_care_config as
select `sd20210809`.`int_intensive_care_config`.`id`               AS `id`,
       `sd20210809`.`int_intensive_care_config`.`config_type`      AS `config_type`,
       `sd20210809`.`int_intensive_care_config`.`config_code`      AS `config_code`,
       `sd20210809`.`int_intensive_care_config`.`config_name`      AS `config_name`,
       `sd20210809`.`int_intensive_care_config`.`config_fieldname` AS `config_fieldname`,
       `sd20210809`.`int_intensive_care_config`.`beid`             AS `beid`,
       `sd20210809`.`int_intensive_care_config`.`create_time`      AS `create_time`,
       `sd20210809`.`int_intensive_care_config`.`create_id`        AS `create_id`,
       `sd20210809`.`int_intensive_care_config`.`update_time`      AS `update_time`,
       `sd20210809`.`int_intensive_care_config`.`update_id`        AS `update_id`,
       `sd20210809`.`int_intensive_care_config`.`remark`           AS `remark`
from `sd20210809`.`int_intensive_care_config`;

