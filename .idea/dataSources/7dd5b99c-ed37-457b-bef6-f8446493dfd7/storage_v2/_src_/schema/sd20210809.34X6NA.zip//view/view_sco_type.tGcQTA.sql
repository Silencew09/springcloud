create definer = root@`%` view view_sco_type as
select `sd20210809`.`sco_type`.`scoTypeId`   AS `scoTypeId`,
       `sd20210809`.`sco_type`.`scoTypeName` AS `scoTypeName`,
       `sd20210809`.`sco_type`.`sort`        AS `sort`,
       `sd20210809`.`sco_type`.`enable`      AS `enable`,
       `sd20210809`.`sco_type`.`isChild`     AS `isChild`,
       `sd20210809`.`sco_type`.`beid`        AS `beid`
from `sd20210809`.`sco_type`;

