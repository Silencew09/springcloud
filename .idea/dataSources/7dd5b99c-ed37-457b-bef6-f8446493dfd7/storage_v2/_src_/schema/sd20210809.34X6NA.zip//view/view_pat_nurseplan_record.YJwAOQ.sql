create definer = root@`%` view view_pat_nurseplan_record as
select `sd20210809`.`pat_nurseplan_record`.`id`           AS `id`,
       `sd20210809`.`pat_nurseplan_record`.`patId`        AS `patId`,
       `sd20210809`.`pat_nurseplan_record`.`nurseType`    AS `nurseType`,
       `sd20210809`.`pat_nurseplan_record`.`nurseId`      AS `nurseId`,
       `sd20210809`.`pat_nurseplan_record`.`nurseItem`    AS `nurseItem`,
       `sd20210809`.`pat_nurseplan_record`.`nurseFreq`    AS `nurseFreq`,
       `sd20210809`.`pat_nurseplan_record`.`startTime`    AS `startTime`,
       `sd20210809`.`pat_nurseplan_record`.`startNurse`   AS `startNurse`,
       `sd20210809`.`pat_nurseplan_record`.`startChecker` AS `startChecker`,
       `sd20210809`.`pat_nurseplan_record`.`endTime`      AS `endTime`,
       `sd20210809`.`pat_nurseplan_record`.`endNurse`     AS `endNurse`,
       `sd20210809`.`pat_nurseplan_record`.`endChecker`   AS `endChecker`,
       `sd20210809`.`pat_nurseplan_record`.`status`       AS `status`,
       `sd20210809`.`pat_nurseplan_record`.`startTime2`   AS `startTime2`,
       `sd20210809`.`pat_nurseplan_record`.`startNurse2`  AS `startNurse2`,
       `sd20210809`.`pat_nurseplan_record`.`endTime2`     AS `endTime2`,
       `sd20210809`.`pat_nurseplan_record`.`endNurse2`    AS `endNurse2`
from `sd20210809`.`pat_nurseplan_record`;

