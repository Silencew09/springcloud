create definer = root@`%` view view_doc_pain_thermogram_day as
select `sd20210809`.`doc_pain_thermogram_day`.`ID`                AS `ID`,
       `sd20210809`.`doc_pain_thermogram_day`.`PATID`             AS `PATID`,
       `sd20210809`.`doc_pain_thermogram_day`.`CREATETIME`        AS `CREATETIME`,
       `sd20210809`.`doc_pain_thermogram_day`.`RECORDDATE`        AS `RECORDDATE`,
       `sd20210809`.`doc_pain_thermogram_day`.`POSTOPERATIVEDAYS` AS `POSTOPERATIVEDAYS`,
       `sd20210809`.`doc_pain_thermogram_day`.`SHIT`              AS `SHIT`,
       `sd20210809`.`doc_pain_thermogram_day`.`URINE`             AS `URINE`,
       `sd20210809`.`doc_pain_thermogram_day`.`WEIGHT`            AS `WEIGHT`,
       `sd20210809`.`doc_pain_thermogram_day`.`HEIGHT`            AS `HEIGHT`,
       `sd20210809`.`doc_pain_thermogram_day`.`BLOODPRESSURE`     AS `BLOODPRESSURE`,
       `sd20210809`.`doc_pain_thermogram_day`.`DRUGALLERGY`       AS `DRUGALLERGY`,
       `sd20210809`.`doc_pain_thermogram_day`.`BEID`              AS `BEID`
from `sd20210809`.`doc_pain_thermogram_day`;

