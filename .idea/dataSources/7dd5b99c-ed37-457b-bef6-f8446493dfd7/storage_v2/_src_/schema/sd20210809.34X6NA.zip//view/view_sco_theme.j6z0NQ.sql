create definer = root@`%` view view_sco_theme as
select `sd20210809`.`sco_theme`.`scoThemeId`         AS `scoThemeId`,
       `sd20210809`.`sco_theme`.`scoThemeName`       AS `scoThemeName`,
       `sd20210809`.`sco_theme`.`scoThemeBriefName`  AS `scoThemeBriefName`,
       `sd20210809`.`sco_theme`.`scoTypeId`          AS `scoTypeId`,
       `sd20210809`.`sco_theme`.`remark`             AS `remark`,
       `sd20210809`.`sco_theme`.`minSco`             AS `minSco`,
       `sd20210809`.`sco_theme`.`maxSco`             AS `maxSco`,
       `sd20210809`.`sco_theme`.`sort`               AS `sort`,
       `sd20210809`.`sco_theme`.`fre`                AS `fre`,
       `sd20210809`.`sco_theme`.`isPositive`         AS `isPositive`,
       `sd20210809`.`sco_theme`.`columnNum`          AS `columnNum`,
       `sd20210809`.`sco_theme`.`enable`             AS `enable`,
       `sd20210809`.`sco_theme`.`roleType`           AS `roleType`,
       `sd20210809`.`sco_theme`.`url`                AS `url`,
       `sd20210809`.`sco_theme`.`beid`               AS `beid`,
       `sd20210809`.`sco_theme`.`isPrint`            AS `isPrint`,
       `sd20210809`.`sco_theme`.`reportprinturl`     AS `reportprinturl`,
       `sd20210809`.`sco_theme`.`singleprinturl`     AS `singleprinturl`,
       `sd20210809`.`sco_theme`.`isneedintervention` AS `isneedintervention`,
       `sd20210809`.`sco_theme`.`reportpagenum`      AS `reportpagenum`
from `sd20210809`.`sco_theme`;

