create definer = root@`%` view view_bas_nurseplan as
select `sd20210809`.`bas_nurseplan`.`nurseId`         AS `nurseId`,
       `sd20210809`.`bas_nurseplan`.`nurseType`       AS `nurseType`,
       `sd20210809`.`bas_nurseplan`.`nurseItem`       AS `nurseItem`,
       `sd20210809`.`bas_nurseplan`.`pinyin`          AS `pinyin`,
       `sd20210809`.`bas_nurseplan`.`nurseFreq`       AS `nurseFreq`,
       `sd20210809`.`bas_nurseplan`.`nurseItemNumber` AS `nurseItemNumber`,
       `sd20210809`.`bas_nurseplan`.`beid`            AS `beid`,
       `sd20210809`.`bas_nurseplan`.`code`            AS `code`,
       `sd20210809`.`bas_nurseplan`.`standardCode`    AS `standardCode`,
       `sd20210809`.`bas_nurseplan`.`standardName`    AS `standardName`
from `sd20210809`.`bas_nurseplan`;

