create definer = root@`%` view view_pat_out_in_record as
select `sd20210809`.`pat_out_in_record`.`id`               AS `id`,
       `sd20210809`.`pat_out_in_record`.`pat_id`           AS `pat_id`,
       `sd20210809`.`pat_out_in_record`.`source_id`        AS `source_id`,
       `sd20210809`.`pat_out_in_record`.`source`           AS `source`,
       `sd20210809`.`pat_out_in_record`.`type`             AS `type`,
       `sd20210809`.`pat_out_in_record`.`name`             AS `name`,
       `sd20210809`.`pat_out_in_record`.`time`             AS `time`,
       `sd20210809`.`pat_out_in_record`.`quantity`         AS `quantity`,
       `sd20210809`.`pat_out_in_record`.`reality_quantity` AS `reality_quantity`,
       `sd20210809`.`pat_out_in_record`.`remain_quantity`  AS `remain_quantity`,
       `sd20210809`.`pat_out_in_record`.`abandon_quantity` AS `abandon_quantity`,
       `sd20210809`.`pat_out_in_record`.`unit`             AS `unit`,
       `sd20210809`.`pat_out_in_record`.`operator`         AS `operator`,
       `sd20210809`.`pat_out_in_record`.`beid`             AS `beid`,
       `sd20210809`.`pat_out_in_record`.`create_time`      AS `create_time`,
       `sd20210809`.`pat_out_in_record`.`create_id`        AS `create_id`,
       `sd20210809`.`pat_out_in_record`.`update_time`      AS `update_time`,
       `sd20210809`.`pat_out_in_record`.`update_id`        AS `update_id`,
       `sd20210809`.`pat_out_in_record`.`remark`           AS `remark`
from `sd20210809`.`pat_out_in_record`;

