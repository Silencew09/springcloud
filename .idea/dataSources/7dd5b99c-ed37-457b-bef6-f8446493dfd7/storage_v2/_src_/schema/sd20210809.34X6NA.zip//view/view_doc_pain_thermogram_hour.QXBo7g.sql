create definer = root@`%` view view_doc_pain_thermogram_hour as
select `sd20210809`.`doc_pain_thermogram_hour`.`ID`              AS `ID`,
       `sd20210809`.`doc_pain_thermogram_hour`.`DAYID`           AS `DAYID`,
       `sd20210809`.`doc_pain_thermogram_hour`.`PATID`           AS `PATID`,
       `sd20210809`.`doc_pain_thermogram_hour`.`CREATETIME`      AS `CREATETIME`,
       `sd20210809`.`doc_pain_thermogram_hour`.`RECORDHOUR`      AS `RECORDHOUR`,
       `sd20210809`.`doc_pain_thermogram_hour`.`TEMPERATURE`     AS `TEMPERATURE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`TEMPERATURETYPE` AS `TEMPERATURETYPE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`COOLING`         AS `COOLING`,
       `sd20210809`.`doc_pain_thermogram_hour`.`UNRISE`          AS `UNRISE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`PULSE`           AS `PULSE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`HEARTRATE`       AS `HEARTRATE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`FALLSHORT`       AS `FALLSHORT`,
       `sd20210809`.`doc_pain_thermogram_hour`.`BREATHE`         AS `BREATHE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`ASSISTBREATHE`   AS `ASSISTBREATHE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`PAINSCORE`       AS `PAINSCORE`,
       `sd20210809`.`doc_pain_thermogram_hour`.`UPEVENT`         AS `UPEVENT`,
       `sd20210809`.`doc_pain_thermogram_hour`.`DOWNEVENT`       AS `DOWNEVENT`,
       `sd20210809`.`doc_pain_thermogram_hour`.`BREAKSIGN`       AS `BREAKSIGN`,
       `sd20210809`.`doc_pain_thermogram_hour`.`RECORDERID`      AS `RECORDERID`,
       `sd20210809`.`doc_pain_thermogram_hour`.`BEID`            AS `BEID`,
       `sd20210809`.`doc_pain_thermogram_hour`.`PORTIME`         AS `PORTIME`
from `sd20210809`.`doc_pain_thermogram_hour`;

