create definer = root@`%` view view_int_intensive_ungather_record as
select `sd20210809`.`int_intensive_ungather_record`.`id`             AS `id`,
       `sd20210809`.`int_intensive_ungather_record`.`int_record_id`  AS `int_record_id`,
       `sd20210809`.`int_intensive_ungather_record`.`pat_id`         AS `pat_id`,
       `sd20210809`.`int_intensive_ungather_record`.`record_time`    AS `record_time`,
       `sd20210809`.`int_intensive_ungather_record`.`option_code`    AS `option_code`,
       `sd20210809`.`int_intensive_ungather_record`.`option_content` AS `option_content`,
       `sd20210809`.`int_intensive_ungather_record`.`beid`           AS `beid`,
       `sd20210809`.`int_intensive_ungather_record`.`create_time`    AS `create_time`,
       `sd20210809`.`int_intensive_ungather_record`.`create_id`      AS `create_id`,
       `sd20210809`.`int_intensive_ungather_record`.`update_time`    AS `update_time`,
       `sd20210809`.`int_intensive_ungather_record`.`update_id`      AS `update_id`,
       `sd20210809`.`int_intensive_ungather_record`.`remark`         AS `remark`
from `sd20210809`.`int_intensive_ungather_record`;

