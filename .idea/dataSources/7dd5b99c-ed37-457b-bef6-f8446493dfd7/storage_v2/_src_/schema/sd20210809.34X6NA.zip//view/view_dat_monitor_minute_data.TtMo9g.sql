create definer = root@`%` view view_dat_monitor_minute_data as
select `sd20210809`.`dat_monitor_minute_data`.`id`               AS `id`,
       `sd20210809`.`dat_monitor_minute_data`.`patId`            AS `patId`,
       `sd20210809`.`dat_monitor_minute_data`.`bedId`            AS `bedId`,
       `sd20210809`.`dat_monitor_minute_data`.`time`             AS `time`,
       `sd20210809`.`dat_monitor_minute_data`.`observeId`        AS `observeId`,
       `sd20210809`.`dat_monitor_minute_data`.`value`            AS `value`,
       `sd20210809`.`dat_monitor_minute_data`.`state`            AS `state`,
       `sd20210809`.`dat_monitor_minute_data`.`observeName`      AS `observeName`,
       `sd20210809`.`dat_monitor_minute_data`.`icon`             AS `icon`,
       `sd20210809`.`dat_monitor_minute_data`.`color`            AS `color`,
       `sd20210809`.`dat_monitor_minute_data`.`freq`             AS `freq`,
       `sd20210809`.`dat_monitor_minute_data`.`position`         AS `position`,
       `sd20210809`.`dat_monitor_minute_data`.`intervalTime`     AS `intervalTime`,
       `sd20210809`.`dat_monitor_minute_data`.`amendFlag`        AS `amendFlag`,
       `sd20210809`.`dat_monitor_minute_data`.`dataSource`       AS `dataSource`,
       `sd20210809`.`dat_monitor_minute_data`.`modifyValue`      AS `modifyValue`,
       `sd20210809`.`dat_monitor_minute_data`.`modifyTime`       AS `modifyTime`,
       `sd20210809`.`dat_monitor_minute_data`.`modifyDataSource` AS `modifyDataSource`,
       `sd20210809`.`dat_monitor_minute_data`.`remark`           AS `remark`,
       `sd20210809`.`dat_monitor_minute_data`.`createTime`       AS `createTime`
from `sd20210809`.`dat_monitor_minute_data`;

