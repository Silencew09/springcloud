create definer = root@`%` view view_pat_nurse_intervent as
select `sd20210809`.`pat_nurse_intervent`.`id`              AS `id`,
       `sd20210809`.`pat_nurse_intervent`.`time`            AS `time`,
       `sd20210809`.`pat_nurse_intervent`.`patId`           AS `patId`,
       `sd20210809`.`pat_nurse_intervent`.`nurseId`         AS `nurseId`,
       `sd20210809`.`pat_nurse_intervent`.`content`         AS `content`,
       `sd20210809`.`pat_nurse_intervent`.`type`            AS `type`,
       `sd20210809`.`pat_nurse_intervent`.`freq`            AS `freq`,
       `sd20210809`.`pat_nurse_intervent`.`sign`            AS `sign`,
       `sd20210809`.`pat_nurse_intervent`.`nurseItemNumber` AS `nurseItemNumber`
from `sd20210809`.`pat_nurse_intervent`;

