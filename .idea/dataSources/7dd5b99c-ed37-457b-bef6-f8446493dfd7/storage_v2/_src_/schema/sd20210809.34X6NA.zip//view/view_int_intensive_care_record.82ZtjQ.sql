create definer = root@`%` view view_int_intensive_care_record as
select `sd20210809`.`int_intensive_care_record`.`id`          AS `id`,
       `sd20210809`.`int_intensive_care_record`.`pat_id`      AS `pat_id`,
       `sd20210809`.`int_intensive_care_record`.`record_time` AS `record_time`,
       `sd20210809`.`int_intensive_care_record`.`other`       AS `other`,
       `sd20210809`.`int_intensive_care_record`.`sign`        AS `sign`,
       `sd20210809`.`int_intensive_care_record`.`beid`        AS `beid`,
       `sd20210809`.`int_intensive_care_record`.`create_time` AS `create_time`,
       `sd20210809`.`int_intensive_care_record`.`create_id`   AS `create_id`,
       `sd20210809`.`int_intensive_care_record`.`update_time` AS `update_time`,
       `sd20210809`.`int_intensive_care_record`.`update_id`   AS `update_id`,
       `sd20210809`.`int_intensive_care_record`.`remark`      AS `remark`
from `sd20210809`.`int_intensive_care_record`;

