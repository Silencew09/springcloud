create definer = root@`%` view view_sco_braden_rec_notice as
select `sd20210809`.`sco_braden_rec_notice`.`id`           AS `id`,
       `sd20210809`.`sco_braden_rec_notice`.`patId`        AS `patId`,
       `sd20210809`.`sco_braden_rec_notice`.`scoValue`     AS `scoValue`,
       `sd20210809`.`sco_braden_rec_notice`.`autograph`    AS `autograph`,
       `sd20210809`.`sco_braden_rec_notice`.`relationship` AS `relationship`,
       `sd20210809`.`sco_braden_rec_notice`.`informer`     AS `informer`,
       `sd20210809`.`sco_braden_rec_notice`.`createTime`   AS `createTime`,
       `sd20210809`.`sco_braden_rec_notice`.`createId`     AS `createId`,
       `sd20210809`.`sco_braden_rec_notice`.`updateTime`   AS `updateTime`,
       `sd20210809`.`sco_braden_rec_notice`.`updateId`     AS `updateId`,
       `sd20210809`.`sco_braden_rec_notice`.`remark1`      AS `remark1`,
       `sd20210809`.`sco_braden_rec_notice`.`remark2`      AS `remark2`
from `sd20210809`.`sco_braden_rec_notice`;

